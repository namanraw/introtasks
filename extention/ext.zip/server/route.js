module.exports = {
	// hello_world is the name of function in this code block
	"/classes/person_class/objects" : {
		GET : {
      _pre : (req,res) =>{
        return this.resSuccess(req,res,req.bobjekt);
      }
    }
	}
}